chrome extension for ESL learners with spanish as their native language. built in... not enough time. will update soon </3
