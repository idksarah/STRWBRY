let button = document.querySelector('button');

let thankYou = document.querySelector('#thankYou');
let likeActually = document.querySelector('likeActually');

button.addEventListener('click', function() {

})